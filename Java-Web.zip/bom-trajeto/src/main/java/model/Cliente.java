package model;

public class Cliente {

	private int id_cli;
	private String nome;
	private String cpf;
	private String nascimento;
	private String email;

	public int getId_cli() {
		return id_cli;
	}

	public void setId_cli(int id_cli) {
		this.id_cli = id_cli;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNascimento() {
		return nascimento;
	}

	public void setNascimento(String nascimento) {
		this.nascimento = nascimento;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Cliente [id_cli=" + id_cli + ", nome=" + nome + ", cpf=" + cpf + ", nascimento=" + nascimento
				+ ", email=" + email + "]";
	}

}
